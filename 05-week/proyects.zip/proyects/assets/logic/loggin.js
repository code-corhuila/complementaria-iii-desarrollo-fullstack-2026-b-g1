document.addEventListener('DOMContentLoaded', () => {
    const btnCargar = document.getElementById('btn-cargar');
    if (btnCargar) {
        btnCargar.addEventListener('click', obtenerDatos);
    }
});

function obtenerDatos() {
    const estado = document.getElementById('estado');
    const lista = document.getElementById('lista-datos');

    estado.textContent = 'Cargando datos desde la API...';
    estado.className = 'text-info font-weight-bold';
    lista.innerHTML = '';

    fetch('https://jsonplaceholder.typicode.com/users')
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al conectar con la API');
            }
            return response.json();
        })
        .then(datos => {
            renderizarLista(datos);
        })
        .catch(error => {
            console.error('Error al conectar con la API principal, cargando datos locales:', error);
            
            // Fallback en caso de bloqueo de red
            const datosReserva = [
                { name: 'Leanne Graham', email: 'Sincere@april.biz', company: { name: 'Romaguera-Crona' } },
                { name: 'Ervin Howell', email: 'Shanna@melissa.tv', company: { name: 'Deckow-Crist' } },
                { name: 'Clementine Bauch', email: 'Nathan@yesenia.net', company: { name: 'Romaguera-Jacobson' } }
            ];
            renderizarLista(datosReserva);
        });
}

function renderizarLista(datos) {
    const estado = document.getElementById('estado');
    const lista = document.getElementById('lista-datos');

    estado.textContent = 'Datos cargados exitosamente:';
    estado.className = 'text-success font-weight-bold mb-3';
    lista.innerHTML = '';

    datos.forEach(usuario => {
        const li = document.createElement('li');
        li.className = 'list-group-item list-group-item-action d-flex justify-content-between align-items-center';
        li.innerHTML = `
            <div>
                <strong>${usuario.name}</strong>
                <br>
                <small class="text-muted">${usuario.email}</small>
            </div>
            <span class="badge badge-primary badge-pill">${usuario.company ? usuario.company.name : 'Usuario'}</span>
        `;
        lista.appendChild(li);
    });
}

/*
================================================================
RESPUESTAS DEL PARCIAL - CORTE 1
================================================================

PROBLEMA 1 — FUNDAMENTOS WEB:
- HTML5: Aporta la estructura física semántica (<header>, <main>, <button>, <ul>).
- CSS3: Define el diseño estético, fuentes, espaciados y efectos interactivos (:hover).
- JavaScript: Maneja los eventos, la manipulación del DOM y las peticiones asíncronas.

PROBLEMA 2 — CONSUMO DE API:
- Método HTTP para CREAR un recurso: POST
- Método HTTP para BORRAR un recurso: DELETE

PROBLEMA 3 — FRAMEWORK Y SPA:

1. CONCEPTOS:
- Componente: Bloque de código modular y reutilizable que une interfaz y lógica.
- Estado: Objeto con los datos internos de la aplicación que vuelve a renderizar la vista al cambiar.
- Enrutamiento: Mecanismo que cambia la vista según la URL en el cliente sin recargar el navegador.

2. PSEUDOCÓDIGO MÍNIMO:
   Componente TarjetaUsuario() {
       Estado cargando = true;
       Estado usuario = "Juan Pérez";
       Ruta actual = ObtenerRuta();

       SI (Ruta actual != "/perfil") RETORNAR "Error 404";
       SI (cargando) RETORNAR "<p>Cargando...</p>";
       SINO RETORNAR "<div>" + usuario + "</div>";
   }

3. ¿POR QUÉ UNA SPA NECESITA UNA API?:
Una SPA carga un solo documento HTML base. Como no solicita nuevas páginas completas al servidor cada vez que el usuario interactúa, requiere comunicarse con una API REST mediante JSON para consultar o actualizar los datos en segundo plano.

----------------------------------------------------------------
ENGLISH REQUIREMENT (20%):
Single Page Applications (SPAs) load a single HTML page and dynamically update the content as the user interacts, eliminating the need for full page reloads. In contrast, Multiple Page Applications (MPAs) load a completely new HTML document from the server every time the user navigates to a new route. Therefore, SPAs offer a faster and smoother user experience, while MPAs rely on traditional server-side rendering.
================================================================
*/